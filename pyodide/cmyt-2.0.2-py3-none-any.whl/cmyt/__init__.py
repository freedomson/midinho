from .cm import *

from importlib.metadata import version

__version__ = version("cmyt")
del version
