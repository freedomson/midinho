from matplotlib.testing.conftest import (mpl_test_settings,  # noqa
                                         pytest_configure, pytest_unconfigure)
