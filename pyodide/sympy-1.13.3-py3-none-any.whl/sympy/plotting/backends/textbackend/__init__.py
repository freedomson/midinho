from sympy.plotting.backends.textbackend.text import TextBackend

__all__ = ["TextBackend"]
